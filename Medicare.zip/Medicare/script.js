function toggleMenu() {
  document.getElementById('menu').classList.toggle('hidden');
}

function logoutUser() {
  localStorage.removeItem('loggedIn');
  window.location.href = 'index.html';
}

function showAccount() {
  alert("👤 Username: " + (localStorage.getItem('username') || 'User') + "\nEmail: demo@medicare.com");
}

// Redirect to login if not signed in
if (window.location.pathname.endsWith('home.html') && !localStorage.getItem('loggedIn')) {
  window.location.href = 'index.html';
}
